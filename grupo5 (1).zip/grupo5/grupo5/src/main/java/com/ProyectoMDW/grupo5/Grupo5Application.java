package com.ProyectoMDW.grupo5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grupo5Application {

	public static void main(String[] args) {
		SpringApplication.run(Grupo5Application.class, args);
	}

}
