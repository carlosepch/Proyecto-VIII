package com.ProyectoMDW.grupo5.Controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PacienteController {
    
    @GetMapping("/dashboard")
    public String mostrarDashboard() {
        return "Administrador/Dashboard"; 
    }

     @GetMapping("/dashboard/CitasAgendadas")
    public String mostrarCitasAgendadas() {
        return "Administrador/CitasAgendadas"; 
    }

     @GetMapping("/dashboard/PromocionesVigentes")
    public String mostrarPromocionesVigentes() {
        return "Administrador/PromocionesVigentes"; 
    }
    @GetMapping("/dashboard/GestionDePacientes")
    public String mostrarGestionDePacientes() {
        return "Administrador/GestionDePacientes"; 
    }
}

