package com.ProyectoMDW.grupo5.Controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class PaginaPrincipalController {
    
// Página principal o inicio
    @GetMapping("/inicio")
    public String mostrarInicio() {
        return "Paciente/index"; 
    }

     @GetMapping("/inicio/login")
    public String mostrarLogin() {
        return "Paciente/Login"; 
    }

     @GetMapping("/inicio/register")
    public String mostrarRegistro() {
        return "Paciente/Registrar"; 
    }
}
